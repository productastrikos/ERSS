/**
 * The demo pilot — auto-run as a person would do it. A finger moves to the real control,
 * scrolls a list when the control is off-screen, pauses to read, and taps: the tap is an
 * actual click on the button a crew member would press, so everything downstream (the
 * server, the console, the citizen's tracking screen) sees an ordinary crew.
 *
 * Controls are found by `data-demo="…"`; nothing here knows how a screen is built.
 */

import { useMemo, useRef, useState } from 'react';

export interface Finger {
  x: number;
  y: number;
  shown: boolean;
  down: boolean;
  drag: boolean;
  ripple: number;
  caption: string | null;
}

const HIDDEN: Finger = { x: 0, y: 0, shown: false, down: false, drag: false, ripple: 0, caption: null };

/** How long the finger takes to travel — matched in pilot.scss. */
const MOVE_MS = 650;
const DRAG_MS = 700;

export interface Pilot {
  /** Off: any tap in flight is dropped, and nothing more is done until it is on again. */
  setActive: (on: boolean) => void;
  tap: (name: string, caption?: string) => Promise<boolean>;
  look: (name: string, caption: string, ms: number) => Promise<boolean>;
  toTop: (name: string) => Promise<void>;
  say: (caption: string | null) => void;
  hide: () => void;
  exists: (name: string) => boolean;
  label: (name: string) => string | null;
  sleep: (ms: number) => Promise<void>;
}

const find = (name: string) => document.querySelector<HTMLElement>(`[data-demo="${name}"]`);

function scrollParent(el: HTMLElement): HTMLElement | null {
  for (let p = el.parentElement; p; p = p.parentElement) {
    const oy = getComputedStyle(p).overflowY;
    if ((oy === 'auto' || oy === 'scroll') && p.scrollHeight > p.clientHeight + 2) return p;
  }
  return null;
}

export function usePilot() {
  const [finger, setFinger] = useState<Finger>(HIDDEN);
  const layer = useRef<HTMLDivElement>(null);
  /** False the moment auto-run is switched off: a tap in flight is not delivered. */
  const alive = useRef(false);

  const pilot = useMemo<Pilot>(() => {
    const sleep = (ms: number) => new Promise<void>((r) => { window.setTimeout(r, ms); });
    const origin = () => layer.current?.getBoundingClientRect() ?? new DOMRect();
    const centre = (el: HTMLElement) => {
      const r = el.getBoundingClientRect();
      const o = origin();
      return { x: r.left - o.left + r.width / 2, y: r.top - o.top + r.height / 2 };
    };

    async function moveTo(x: number, y: number, caption?: string) {
      setFinger((f) => ({ ...f, shown: true, x, y, caption: caption ?? f.caption }));
      await sleep(MOVE_MS + 80);
    }

    /** A swipe on the list the control is in, until the control is comfortably in view. */
    async function swipeTo(el: HTMLElement, where: 'into-view' | 'top') {
      const box = scrollParent(el);
      if (!box) return;
      const r = el.getBoundingClientRect();
      const b = box.getBoundingClientRect();
      const delta = where === 'top' ? -box.scrollTop : r.top - (b.top + b.height * 0.35);
      if (where === 'into-view' && r.top >= b.top + 12 && r.bottom <= b.bottom - 12) return;
      if (Math.abs(delta) < 8) return;
      const o = origin();
      const x = b.left - o.left + b.width * 0.7;
      const span = Math.min(200, b.height * 0.45);
      const from = delta > 0 ? b.top - o.top + b.height * 0.72 : b.top - o.top + b.height * 0.28;
      await moveTo(x, from);
      setFinger((f) => ({ ...f, down: true, drag: true }));
      await sleep(120);
      box.scrollBy({ top: delta, behavior: 'smooth' });
      setFinger((f) => ({ ...f, y: delta > 0 ? from - span : from + span }));
      await sleep(DRAG_MS);
      setFinger((f) => ({ ...f, down: false, drag: false }));
      await sleep(250);
    }

    async function tap(name: string, caption?: string) {
      let el = find(name);
      if (!el || !alive.current) return false;
      if (caption) setFinger((f) => ({ ...f, caption }));
      await swipeTo(el, 'into-view');
      el = find(name);
      if (!el || !alive.current) return false;
      const c = centre(el);
      await moveTo(c.x, c.y, caption);
      await sleep(380);
      if (!alive.current) return false;
      setFinger((f) => ({ ...f, down: true, ripple: f.ripple + 1 }));
      await sleep(170);
      const target = find(name);
      if (!target || !alive.current || (target as HTMLButtonElement).disabled) {
        setFinger((f) => ({ ...f, down: false }));
        return false;
      }
      target.click();
      setFinger((f) => ({ ...f, down: false }));
      await sleep(450);
      // Lifted off the screen: a finger left resting where the NEXT button appears would
      // read as pressing it.
      setFinger((f) => ({ ...f, shown: false }));
      return true;
    }

    async function look(name: string, caption: string, ms: number) {
      const el = find(name);
      if (!el || !alive.current) return false;
      setFinger((f) => ({ ...f, caption }));
      await swipeTo(el, 'into-view');
      const again = find(name);
      if (again) {
        const r = again.getBoundingClientRect();
        const o = origin();
        await moveTo(r.left - o.left + Math.min(r.width - 24, 48), r.top - o.top + Math.min(r.height - 12, 36), caption);
      }
      await sleep(ms);
      setFinger((f) => ({ ...f, shown: false }));
      return true;
    }

    async function toTop(name: string) {
      const el = find(name);
      const box = el && (el.scrollTop > 0 ? el : scrollParent(el));
      if (!box || box.scrollTop <= 0) return;
      const first = box.firstElementChild as HTMLElement | null;
      if (first) await swipeTo(first, 'top');
      setFinger((f) => ({ ...f, shown: false }));
    }

    return {
      setActive: (on) => { alive.current = on; },
      tap, look, toTop, sleep,
      say: (caption) => setFinger((f) => ({ ...f, caption })),
      hide: () => setFinger(HIDDEN),
      exists: (name) => Boolean(find(name)),
      label: (name) => find(name)?.getAttribute('data-demo-label') ?? null,
    };
  }, []);

  return { finger, layer, pilot };
}
