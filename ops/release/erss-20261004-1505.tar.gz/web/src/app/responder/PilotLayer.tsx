import { Hand } from 'lucide-react';
import type { Finger } from './usePilot';

/** The pilot's finger and what it is doing, drawn over the whole app (usePilot.ts). */
export function PilotLayer({ finger, layerRef }: { finger: Finger; layerRef: React.RefObject<HTMLDivElement | null> }) {
  return (
    <div className="pilot" ref={layerRef} aria-hidden>
      {finger.caption && (
        <div className="pilot__caption"><Hand /> {finger.caption}</div>
      )}
      {finger.shown && (
        <span className={`pilot__finger${finger.down ? ' is-down' : ''}${finger.drag ? ' is-drag' : ''}`}
              style={{ transform: `translate(${finger.x}px, ${finger.y}px)` }}>
          <span className="pilot__dot" />
          {finger.ripple > 0 && <span key={finger.ripple} className="pilot__ripple" />}
        </span>
      )}
    </div>
  );
}
