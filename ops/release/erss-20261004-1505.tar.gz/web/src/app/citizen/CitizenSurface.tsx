/**
 * Citizen surface — the public SOS application. docs/07 §4.
 *
 * Sliding to send prevents pocket dialling. The four direct-dial buttons are ALWAYS
 * present: the app must never be the only way to get help.
 *
 * The health monitor runs under every tab: when a reading stays past a limit, a countdown
 * takes the screen, and if nobody says they're OK the SOS goes by itself.
 */

import { useState, useRef, useCallback, useEffect } from 'react';
import { Activity, Asterisk, BookOpen, ClipboardPlus, Home, MapPin, Menu, VolumeX, X, Ambulance } from 'lucide-react';
import type { NearestAmbulance, SosStatus } from '../../lib/types';
import { useSession, signOut } from '../../lib/stores/session';
import { api, ApiError } from '../../lib/api';
import { t } from '../../lib/i18n';
import { makani as fmtMakani, relative, distance as fmtDistance, UNIT_KIND_LABEL } from '../../lib/format';
import { Card, Button, Field, ErrorState, Skeleton } from '../../shared/ui';
import { EmergencyNumbers } from '../MobileApp';
import { TrackMap, type TrackUnit } from '../TrackMap';
import { citizenMap, inDubai } from '../mobileMap';
import { CONCERN_KIND, CONCERN_SHORT, formatFor, formatValue, sosNote } from './health';
import { useHealthMonitor } from './useHealthMonitor';
import { HealthPanel, VitalsStrip } from './HealthPanel';
import { SosAlert } from './SosAlert';
import { SosSlider } from './SosSlider';
import './citizen.scss';

type Tab = 'home' | 'health' | 'medical' | 'guide' | 'more';

interface ActiveSos { ref: string; kind: string; auto: string | null }

interface SendRequest { kind: string; silent: boolean; note?: string; auto?: string }

export function CitizenSurface() {
  const { user } = useSession();
  const [tab, setTab] = useState<Tab>('home');
  const [activeSos, setActiveSos] = useState<ActiveSos | null>(null);
  const [sending, setSending] = useState(false);
  const [sendError, setSendError] = useState<string | null>(null);
  const [location, posRef] = useSosLocation();
  const monitor = useHealthMonitor(activeSos != null);

  const send = useCallback(async (req: SendRequest): Promise<boolean> => {
    const p = posRef.current;
    if (!p) { setSendError('No location fix yet — try again in a moment, or call 998.'); return false; }
    setSending(true);
    setSendError(null);
    try {
      const r = await api.sos.create({ kind: req.kind, lng: p.lng, lat: p.lat, accuracy: p.accuracy, silent: req.silent, note: req.note });
      navigator.vibrate?.(req.silent ? 40 : [80, 60, 80]);
      setActiveSos({ ref: r.ref, kind: req.kind, auto: req.auto ?? null });
      setTab('home');
      return true;
    } catch (e) {
      setSendError((e as ApiError).message ?? 'Could not send — call 998 directly.');
      return false;
    } finally {
      setSending(false);
    }
  }, [posRef]);

  const alarm = activeSos ? null : monitor.trigger;

  async function sendAutomatic() {
    if (!alarm) return;
    const ok = await send({
      kind: CONCERN_KIND[alarm.concern],
      silent: true,
      note: sosNote(alarm, monitor.rules, monitor.deviceName ?? 'health monitor'),
      auto: `${CONCERN_SHORT[alarm.concern]}, ${formatValue(alarm.concern, alarm.value)} for ${formatFor(alarm.forSec)}`,
    });
    if (ok) monitor.consume(10 * 60_000);
  }

  return (
    <div className="m-shell">
      <header className="m-topbar">
        <div className="m-topbar__id">{t('app.name')}</div>
        <div className="m-topbar__spacer" />
        <span className="m-topbar__status">{user?.name}</span>
      </header>

      <main className="m-content">
        {tab === 'home' && (
          activeSos
            ? <TrackingPanel sosRef={activeSos.ref} kind={activeSos.kind} auto={activeSos.auto} onDone={() => setActiveSos(null)} />
            : <SosPanel location={location} sending={sending} error={sendError}
                        vitals={<VitalsStrip monitor={monitor} onOpen={() => setTab('health')} />}
                        onSend={(kind, silent) => void send({ kind, silent })}
                        onMedical={() => setTab('medical')} />
        )}

        {tab === 'health' && <HealthPanel monitor={monitor} />}
        {tab === 'medical' && <MedicalProfilePanel />}
        {tab === 'guide' && <FirstAidGuide />}

        {tab === 'more' && (
          <Card title="More">
            <Button variant="secondary" size="lg" block onClick={() => void signOut()}>
              {t('auth.signOut')}
            </Button>
          </Card>
        )}
      </main>

      <nav className="m-tabs" aria-label="Sections">
        <TabButton current={tab} value="home"    onSelect={setTab} icon={Home}          label="Home" />
        <TabButton current={tab} value="health"  onSelect={setTab} icon={Activity}      label="Health" />
        <TabButton current={tab} value="medical" onSelect={setTab} icon={ClipboardPlus} label="Medical" />
        <TabButton current={tab} value="guide"   onSelect={setTab} icon={BookOpen}      label="Guide" />
        <TabButton current={tab} value="more"    onSelect={setTab} icon={Menu}          label="More" />
      </nav>

      {alarm && (
        <SosAlert key={`${alarm.concern}:${alarm.forSec}`} alarm={alarm} seconds={monitor.rules.countdownSec}
                  sending={sending} error={sendError}
                  onSend={() => void sendAutomatic()}
                  onCancel={() => { setSendError(null); monitor.dismiss(5 * 60_000); }} />
      )}
    </div>
  );
}

// ── Location — watched from sign-in, so an SOS never waits for a first fix ─────

const HAS_GEOLOCATION = typeof navigator !== 'undefined' && 'geolocation' in navigator;

/** Where a tester outside Dubai can place themselves — inside the trial catchment, where
 *  the eight trial ambulances are (server config/poc.js). A phone in Dubai uses its GPS. */
const DEMO_PLACES = [
  { key: 'dso', label: 'Dubai Silicon Oasis', lng: 55.3790, lat: 25.1180 },
  { key: 'intl', label: 'International City', lng: 55.4100, lat: 25.1600 },
  { key: 'academic', label: 'Academic City', lng: 55.4040, lat: 25.1130 },
  { key: 'mirdif', label: 'Mirdif', lng: 55.4200, lat: 25.2150 },
];

/** "What is happening?" — four plain choices a frightened caller can make in a second. */
const SOS_KINDS = [
  { key: 'medical_general', label: 'Unwell' },
  { key: 'cardiac', label: 'Chest pain' },
  { key: 'cardiac_arrest', label: 'Not breathing' },
  { key: 'trauma_fall', label: 'Injury / fall' },
] as const;

interface Position { lng: number; lat: number; accuracy: number }

interface SosLocation {
  pos: Position | null;
  /** The phone's own fix, whether or not it is the one in use. */
  gps: Position | null;
  place: (typeof DEMO_PLACES)[number] | null;
  gpsUsable: boolean;
  message: string | null;
  choose: (key: string | null) => void;
}

/** The current position, and a ref to it for the send path, which may run from a timer. */
function useSosLocation(): [SosLocation, React.RefObject<Position | null>] {
  const [gpsPos, setGpsPos] = useState<Position | null>(null);
  const [geoError, setGeoError] = useState<string | null>(null);
  const [demoPlace, setDemoPlace] = useState<string | null>(null);

  // A fix outside Dubai (a tester elsewhere) cannot be served by DCAS: use a Dubai place.
  const gpsUsable = gpsPos != null && inDubai(gpsPos.lng, gpsPos.lat);
  const place = DEMO_PLACES.find((p) => p.key === demoPlace) ?? (!gpsUsable ? DEMO_PLACES[0] : null);
  const pos = place ? { lng: place.lng, lat: place.lat, accuracy: 10 } : gpsPos;
  const posRef = useRef<Position | null>(pos);

  useEffect(() => { posRef.current = pos; });

  useEffect(() => {
    if (!HAS_GEOLOCATION) return;
    const id = navigator.geolocation.watchPosition(
      (p) => { setGpsPos({ lng: p.coords.longitude, lat: p.coords.latitude, accuracy: p.coords.accuracy }); setGeoError(null); },
      (err) => setGeoError(
        err.code === err.PERMISSION_DENIED
          ? 'Location permission is off. Turn it on, or call 998 directly.'
          : 'Waiting for a location fix…',
      ),
      { enableHighAccuracy: true, maximumAge: 10_000, timeout: 15_000 },
    );
    return () => navigator.geolocation.clearWatch(id);
  }, []);

  const message = place ? null : !HAS_GEOLOCATION ? 'This device cannot provide a location.' : geoError;
  return [{ pos, gps: gpsPos, place, gpsUsable, message, choose: setDemoPlace }, posRef];
}

// ── SOS ──────────────────────────────────────────────────────────────────────

function SosPanel({ location, sending, error, vitals, onSend, onMedical }: {
  location: SosLocation;
  sending: boolean;
  error: string | null;
  vitals: React.ReactNode;
  onSend: (kind: string, silent: boolean) => void;
  onMedical: () => void;
}) {
  const [kind, setKind] = useState<string>('medical_general');
  const [silent, setSilent] = useState(false);

  return (
    <>
      {vitals}
      {error && <ErrorState body={error} />}

      <div className="c-kinds" role="group" aria-label="What is happening?">
        {SOS_KINDS.map((k) => (
          <button key={k.key} type="button" aria-pressed={kind === k.key} onClick={() => setKind(k.key)}>{k.label}</button>
        ))}
      </div>

      <section className="c-sos" aria-label="Emergency">
        <SosSlider label={sending ? 'Sending…' : 'Emergency SOS'} knob="SOS" disabled={sending}
                   onComplete={() => onSend(kind, silent)} />
        <SosSlider tone="light" label="Medical info" knob={<Asterisk aria-hidden />} onComplete={onMedical} />
        <div className="c-sos__foot">
          <span>Slide to call an ambulance. Your location and medical info go with it.</span>
          <button type="button" className="c-sos__silent" aria-pressed={silent} onClick={() => setSilent((s) => !s)}>
            <VolumeX aria-hidden /> Silent SOS {silent ? 'on' : 'off'}
          </button>
        </div>
      </section>

      <PlacePicker location={location} />

      <EmergencyNumbers />
    </>
  );
}

// ── Where the SOS goes from — every option says who would come, and how soon ────

interface PlaceOption { key: string; label: string; detail: string | null; lng: number; lat: number }

/** The nearest free ambulance to each place, refreshed while the picker is on screen. */
function useNearest(places: PlaceOption[]): Map<string, NearestAmbulance | null> {
  const [out, setOut] = useState<Map<string, NearestAmbulance | null>>(new Map());
  const key = places.map((p) => `${p.key}:${p.lng.toFixed(4)},${p.lat.toFixed(4)}`).join('|');
  const placesRef = useRef(places);
  useEffect(() => { placesRef.current = places; });
  useEffect(() => {
    let cancelled = false;
    const load = () => {
      const list = placesRef.current;
      if (!list.length) return;
      api.sos.nearest(list.map((p) => [p.lng, p.lat]))
        .then((rows) => { if (!cancelled) setOut(new Map(list.map((p, i) => [p.key, rows[i] ?? null]))); })
        .catch(() => { /* the picker still works without the estimates */ });
    };
    load();
    const id = window.setInterval(load, 20_000);
    return () => { cancelled = true; window.clearInterval(id); };
  }, [key]);
  return out;
}

const minutes = (sec: number) => `${Math.max(1, Math.round(sec / 60))} min`;

function PlacePicker({ location }: { location: SosLocation }) {
  const [open, setOpen] = useState(false);
  const { pos, place, gpsUsable, message } = location;
  const options: PlaceOption[] = [
    ...(gpsUsable && location.gps ? [{ key: 'gps', label: 'My GPS position', detail: `±${Math.round(location.gps.accuracy)} m`, lng: location.gps.lng, lat: location.gps.lat }] : []),
    ...DEMO_PLACES.map((p) => ({ key: p.key, label: p.label, detail: null, lng: p.lng, lat: p.lat })),
  ];
  const nearest = useNearest(options);
  const currentKey = place?.key ?? 'gps';
  const current = nearest.get(currentKey);

  return (
    <div className="c-where">
      {message ? (
        <span>{message}</span>
      ) : pos ? (
        <div className="c-where__now">
          <div className="c-where__place">
            <MapPin aria-hidden />
            <span>
              <small>{t('citizen.yourLocation')}{place ? ' (demo)' : ''}</small>
              <strong>{place ? place.label : `${pos.lat.toFixed(5)}, ${pos.lng.toFixed(5)}`}</strong>
              {!place && <small>±{Math.round(pos.accuracy)} m · Makani {fmtMakani(null)}</small>}
            </span>
            <button type="button" className="c-where__change" aria-expanded={open} onClick={() => setOpen((o) => !o)}>
              {open ? 'Done' : gpsUsable ? 'Change' : 'Outside Dubai — change'}
            </button>
          </div>
          <NearestLine n={current} />
        </div>
      ) : (
        <span>Getting your location…</span>
      )}

      {open && (
        <ul className="c-places" role="listbox" aria-label="Send the SOS from">
          {options.map((o) => {
            const n = nearest.get(o.key);
            return (
              <li key={o.key}>
                <button type="button" role="option" aria-selected={o.key === currentKey}
                        onClick={() => { location.choose(o.key === 'gps' ? null : o.key); setOpen(false); }}>
                  <span className="c-places__name">{o.label}{o.detail && <small> · {o.detail}</small>}</span>
                  <NearestLine n={n} compact />
                </button>
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );
}

function NearestLine({ n, compact }: { n: NearestAmbulance | null | undefined; compact?: boolean }) {
  if (n === undefined) return <span className="c-near is-loading">Finding the nearest ambulance…</span>;
  if (n === null) return <span className="c-near is-none">No free ambulance nearby — call 998</span>;
  return (
    <span className={`c-near${compact ? ' is-compact' : ''}`}>
      <Ambulance aria-hidden />
      {!compact && <span>Nearest ambulance</span>}
      <strong>{n.callsign}</strong>
      <span>{fmtDistance(n.distanceM)}</span>
      <span className="c-near__eta">~{minutes(n.etaSec)}</span>
    </span>
  );
}

// ── Tracking ─────────────────────────────────────────────────────────────────

const STEPS = [
  { key: 'received', label: 'Received' },
  { key: 'assigned', label: 'Ambulance assigned' },
  { key: 'onway', label: 'On the way' },
  { key: 'arrived', label: 'Arrived' },
] as const;

/** While-you-wait advice, matched to what the caller said is happening. */
const WAIT_TIP: Record<string, string> = {
  cardiac_arrest: 'Push hard and fast in the centre of the chest — 100 to 120 a minute. Do not stop until the crew takes over.',
  cardiac: 'Sit the person down and keep them still. Loosen tight clothing. If they stop breathing, start CPR.',
  trauma_fall: 'Do not move them unless they are in danger. Press firmly on any bleeding with a clean cloth.',
  medical_general: 'Stay with the person. Unlock the door and switch on a light so the crew finds you fast.',
};

function TrackingPanel({ sosRef, kind, auto, onDone }: { sosRef: string; kind: string; auto: string | null; onDone: () => void }) {
  const [status, setStatus] = useState<SosStatus | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [cancelling, setCancelling] = useState(false);

  useEffect(() => {
    let cancelled = false;
    const poll = () => api.sos.status(sosRef)
      .then((r) => { if (!cancelled) { setStatus(r); setError(null); } })
      .catch((e: ApiError) => { if (!cancelled) setError(e.message); });
    poll();
    // Fast enough that the ambulance visibly moves toward the caller.
    const id = setInterval(poll, 2500);
    return () => { cancelled = true; clearInterval(id); };
  }, [sosRef]);

  async function cancel() {
    setCancelling(true);
    try { await api.sos.cancel(sosRef); onDone(); } catch (e) { setError((e as ApiError).message); } finally { setCancelling(false); }
  }

  const closed = status?.state === 'closed';
  const asg = status?.assignmentState ?? null;
  const arrived = asg === 'onscene' || asg === 'transporting' || asg === 'at_hospital' || asg === 'resolved_on_scene' || asg === 'cleared' || !!status?.onsceneAt;
  const onWay = asg === 'enroute';
  const step = !status ? 0 : arrived ? 3 : onWay ? 2 : asg ? 1 : 0;

  const headline = !status ? 'Sending your SOS…'
    : closed ? 'This request is closed'
    : asg === 'transporting' ? 'On the way to hospital'
    : arrived ? 'The ambulance is with you'
    : onWay ? 'Ambulance on the way'
    : asg ? 'Ambulance assigned — preparing to leave'
    : 'Finding the nearest ambulance…';

  const unit: TrackUnit | null = status?.unitRef && status.unitLng != null && status.unitLat != null && !closed ? {
    ref: status.unitRef, callsign: status.unitCallsign ?? status.unitRef, kind: status.unitKind ?? 'ALS',
    status: arrived ? 'on_scene' : onWay ? 'responding' : 'assigned',
    lng: status.unitLng, lat: status.unitLat, heading: status.unitHeading != null ? Number(status.unitHeading) : null,
  } : null;
  const me = status?.incidentLng != null && status.incidentLat != null ? { lng: status.incidentLng, lat: status.incidentLat } : null;

  return (
    <>
      <div className="c-track">
        <div className="c-track__map">
          <TrackMap view={citizenMap} target={me} unit={unit} route={status?.route ?? null}
                    fitKey={`${sosRef}:${status?.unitRef ?? 'none'}:${step}`} />
        </div>

        <div className="c-track__card">
          {auto && (
            <div className="c-track__auto"><Activity aria-hidden /> Sent automatically · {auto}</div>
          )}
          <div className="c-track__headline">{headline}</div>
          {status && !closed && !arrived && status.etaSec != null && (
            <div className="c-track__eta">
              <span className="c-track__eta-value">{Math.max(1, Math.round(status.etaSec / 60))}</span>
              <span className="c-track__eta-unit">min</span>
              {status.distanceM != null && <span className="c-track__eta-dist">{fmtDistance(status.distanceM)} away</span>}
            </div>
          )}
          {status?.unitCallsign && (
            <div className="c-track__unit">
              <Ambulance aria-hidden /> <strong>{status.unitCallsign}</strong>
              <span>{UNIT_KIND_LABEL[status.unitKind ?? ''] ?? status.unitKind}</span>
            </div>
          )}
          {!status && <Skeleton height={40} />}

          <ol className="c-steps">
            {STEPS.map((s, i) => (
              <li key={s.key} data-state={i < step ? 'done' : i === step ? 'current' : 'todo'}>
                <span className="c-steps__dot" aria-hidden />
                <span>{s.label}</span>
              </li>
            ))}
          </ol>
          <div className="c-track__ref mono">{sosRef}</div>
        </div>
      </div>

      {error && <ErrorState body={error} />}

      {!closed && !arrived && (
        <Card title="While you wait" variant="flat">
          <p className="c-track__tip">{WAIT_TIP[kind] ?? WAIT_TIP.medical_general}</p>
        </Card>
      )}

      {status?.timeline && status.timeline.length > 0 && (
        <Card title="Timeline">
          <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--sp-8)' }}>
            {status.timeline.slice().reverse().map((row, i) => (
              <div key={i} style={{ display: 'flex', justifyContent: 'space-between', gap: 'var(--sp-10)', fontSize: 12.5 }}>
                <span>{row.label}</span>
                <span style={{ color: 'var(--app-text-faint)', whiteSpace: 'nowrap' }}>{relative(row.ts)}</span>
              </div>
            ))}
          </div>
        </Card>
      )}

      {!closed && (
        <Button variant="danger" size="lg" block loading={cancelling} onClick={() => void cancel()}>
          <X aria-hidden /> Cancel SOS
        </Button>
      )}
      {closed && <Button variant="secondary" size="lg" block onClick={onDone}>Done</Button>}

      <EmergencyNumbers />
    </>
  );
}

// ── Medical profile ──────────────────────────────────────────────────────────

interface MedicalProfile {
  [key: string]: unknown;
  bloodGroup?: string | null; allergies?: string[]; conditions?: string[]; medications?: string[];
  emergencyContact?: { name: string; phone: string } | null;
}

function MedicalProfilePanel() {
  const [profile, setProfile] = useState<MedicalProfile | null>(null);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    api.me.medicalProfile().then((p) => { if (!cancelled) setProfile(p as MedicalProfile); }).catch((e: ApiError) => { if (!cancelled) setError(e.message); });
    return () => { cancelled = true; };
  }, []);

  async function save() {
    if (!profile) return;
    setSaving(true); setSaved(false); setError(null);
    try { await api.me.setMedicalProfile(profile); setSaved(true); }
    catch (e) { setError((e as ApiError).message); }
    finally { setSaving(false); }
  }

  const csv = (v?: string[]) => (v ?? []).join(', ');
  const fromCsv = (s: string) => s.split(',').map((x) => x.trim()).filter(Boolean);

  return (
    <Card title={t('citizen.medicalProfile')} subtitle="Sent with an SOS, shown only to the responding crew.">
      {error && <ErrorState body={error} />}
      {!profile ? <Skeleton height={200} /> : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--sp-12)' }}>
          <Field label="Blood group">
            <input value={profile.bloodGroup ?? ''} placeholder="e.g. O+"
                   onChange={(e) => setProfile({ ...profile, bloodGroup: e.target.value })} />
          </Field>
          <Field label="Allergies" help="Comma-separated">
            <input value={csv(profile.allergies)} onChange={(e) => setProfile({ ...profile, allergies: fromCsv(e.target.value) })} />
          </Field>
          <Field label="Conditions" help="Comma-separated">
            <input value={csv(profile.conditions)} onChange={(e) => setProfile({ ...profile, conditions: fromCsv(e.target.value) })} />
          </Field>
          <Field label="Medications" help="Comma-separated">
            <input value={csv(profile.medications)} onChange={(e) => setProfile({ ...profile, medications: fromCsv(e.target.value) })} />
          </Field>
          <Field label="Emergency contact name">
            <input value={profile.emergencyContact?.name ?? ''}
                   onChange={(e) => setProfile({ ...profile, emergencyContact: { name: e.target.value, phone: profile.emergencyContact?.phone ?? '' } })} />
          </Field>
          <Field label="Emergency contact phone">
            <input value={profile.emergencyContact?.phone ?? ''}
                   onChange={(e) => setProfile({ ...profile, emergencyContact: { name: profile.emergencyContact?.name ?? '', phone: e.target.value } })} />
          </Field>
          <Button variant="primary" size="lg" block loading={saving} onClick={() => void save()}>{saved ? 'Saved' : 'Save'}</Button>
        </div>
      )}
    </Card>
  );
}

// ── First-aid guide — static, offline-readable ──────────────────────────────

const GUIDE = [
  { title: 'Cardiac arrest / CPR', body: 'Call 998. Push hard and fast in the centre of the chest, 100–120 compressions per minute, at least 5cm deep. Let the chest fully rise between compressions. Continue until help arrives or an AED is available.' },
  { title: 'Choking (adult)', body: '5 back blows between the shoulder blades, then 5 abdominal thrusts (Heimlich). Repeat until the object clears or the person becomes unresponsive — then begin CPR.' },
  { title: 'Severe bleeding', body: 'Apply firm, direct pressure with a clean cloth. Do not remove an embedded object. Keep pressure until help arrives; elevate the limb if possible.' },
  { title: 'Stroke — F.A.S.T.', body: 'Face drooping, Arm weakness, Speech difficulty — Time to call 998. Note the time symptoms started; it changes treatment options.' },
  { title: 'Heat illness', body: 'Move to shade or cooling, remove excess clothing, cool with water or ice packs at neck/armpits/groin. Call 998 if confusion, no sweating, or loss of consciousness.' },
];

function FirstAidGuide() {
  const [open, setOpen] = useState<number | null>(null);
  return (
    <Card title="First aid" subtitle="Available without a connection — read while help is on the way.">
      <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--sp-8)' }}>
        {GUIDE.map((g, i) => (
          <div key={g.title}>
            <button type="button" onClick={() => setOpen(open === i ? null : i)}
              style={{ width: '100%', textAlign: 'start', background: 'var(--app-surface-raised)', borderRadius: 'var(--r-10)', padding: 'var(--sp-12)', fontWeight: 700 }}>
              {g.title}
            </button>
            {open === i && <p style={{ padding: 'var(--sp-10) var(--sp-4)', fontSize: 13.5, color: 'var(--app-text-muted)' }}>{g.body}</p>}
          </div>
        ))}
      </div>
    </Card>
  );
}

function TabButton({ current, value, onSelect, icon: Icon, label }: {
  current: Tab; value: Tab; onSelect: (t: Tab) => void;
  icon: typeof Home; label: string;
}) {
  return (
    <button type="button" aria-current={current === value ? 'page' : undefined}
            onClick={() => onSelect(value)}>
      <Icon aria-hidden />
      <span>{label}</span>
    </button>
  );
}
